//
//  APIExtension.swift
//  AlexHTTP
//
//  Created by Alexander Rojas Benavides on 9/24/21.
//

import Foundation
extension API {
    
    public static func getNSUrlForAnime(animeId: String) -> URLRequest {
       
        let request = NSMutableURLRequest(url: NSURL(string: "https://\(JikanHost)/anime/\(animeId)")! as URL,
                                          cachePolicy: .useProtocolCachePolicy,
                                          timeoutInterval: 100.0)
        request.httpMethod = "GET"
        return request as URLRequest
    }
    
    public static func getNSUrlForBitly(urlToShort: String) -> URLRequest {
       
        let request = NSMutableURLRequest(url: NSURL(string: "https://\(BitlyHost)/shorten")! as URL,
                                          cachePolicy: .useProtocolCachePolicy,
                                          timeoutInterval: 100.0)
        //request.setValue("application/json", forHTTPHeaderField: "Content-Type")
      //   request.setValue("Bearer {TOKEN}", forHTTPHeaderField: "Authorization")
       let headers = [
           "Authorization": "Bearer {token}",
           "Content-Type": "application/json",
       ]

        request.httpMethod = "POST"
        let parameters: [String: Any] = [
            "long_url": "https://apps.apple.com/app/age-info/id1569664398"
        ]
        request.httpBody = parameters.percentEncoded()
        request.allHTTPHeaderFields = headers
        return request as URLRequest
    }
}
