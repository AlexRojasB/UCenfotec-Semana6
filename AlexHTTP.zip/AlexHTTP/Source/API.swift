//
//  API.swift
//  AlexHTTP
//
//  Created by Alexander Rojas Benavides on 9/24/21.
//

import Foundation

public final class API{
    static let JikanHost = "api.jikan.moe/v3"
    static let BitlyHost = "api-ssl.bitly.com/v4"
}

