//
//  Bitly.swift
//  AlexHTTP_Example
//
//  Created by Alexander Rojas Benavides on 9/25/21.
//  Copyright © 2021 CocoaPods. All rights reserved.
//

import Foundation
struct Bitly : Codable {
    let link: String
}
