//
//  ViewController.swift
//  AlexHTTP
//
//  Created by 39141911 on 09/24/2021.
//  Copyright (c) 2021 39141911. All rights reserved.
//

import UIKit
import AlexHTTP

class ViewController: UIViewController {
    @IBOutlet weak var animeName: UILabel!
    @IBOutlet weak var animeEpisodes: UILabel!
    @IBOutlet weak var shortLinkLabel: UILabel!
    @IBOutlet weak var shortUrlTF: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func getRandomAnime(_ sender: UIButton) {
        let randomInt = Int.random(in: 1..<500)
        let animeURL = API.getNSUrlForAnime(animeId: String(randomInt))
        
        NetworkManager<Anime>.fetch(for: animeURL) {
                  (result) in
                  switch result {
                  case .success(let response):
                      DispatchQueue.main.async {
                          self.animeName.text = "Anime: \(response.title)"
                          self.animeEpisodes.text = "Episodes: \(response.episodes)"
                      }
                      
                  case .failure(let error):
                      print(error)
                  }
              }
    }
    
    @IBAction func postShorttenLink(_ sender: UIButton) {
        guard let urlTF = shortUrlTF.text else {
            return
        }
        
        let shortUrl = API.getNSUrlForBitly(urlToShort: urlTF)
        
        NetworkManager<Bitly>.fetch(for: shortUrl) {
                  (result) in
                  switch result {
                  case .success(let response):
                      DispatchQueue.main.async {
                          self.shortLinkLabel.text = "Short link \(response.link)"
                      }
                      
                  case .failure(let error):
                      print(error)
                  }
              }
    }
}

