# AlexHTTP

[![CI Status](https://img.shields.io/travis/39141911/AlexHTTP.svg?style=flat)](https://travis-ci.org/39141911/AlexHTTP)
[![Version](https://img.shields.io/cocoapods/v/AlexHTTP.svg?style=flat)](https://cocoapods.org/pods/AlexHTTP)
[![License](https://img.shields.io/cocoapods/l/AlexHTTP.svg?style=flat)](https://cocoapods.org/pods/AlexHTTP)
[![Platform](https://img.shields.io/cocoapods/p/AlexHTTP.svg?style=flat)](https://cocoapods.org/pods/AlexHTTP)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

AlexHTTP is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'AlexHTTP'
```

## Author

39141911, alexrrojas.b@gmail.com

## License

AlexHTTP is available under the MIT license. See the LICENSE file for more info.
